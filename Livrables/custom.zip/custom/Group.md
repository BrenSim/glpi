## Les groupes à créer pour l'application

courriel_responsable: groupe regroupant les emails à mettre dans le document à exporter en pdf
Demandeur : groupe regroupant les demandeurs qui fait le signalement de dysfonctionnement
Direction/Service (validation): groupe regroupant les valideurs des signalements