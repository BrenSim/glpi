<meta charset="utf-8" />
<pre>
<?php
    // Inclusion du fichier de configuration
    include('config.php');
    // Décommenter pour voir le contenu de $_POST
    // print_r($_POST);

    // Variable permettant de décider si les tables doivent être vidées (en provenance d'un formulaire POST)
    $truncate_tables =  $_POST['truncate_table'];
    // Fonction pour convertir une date du format français au format ANSI
    function dateFr2Ansi($date) { return implode('-', array_reverse(explode('/', $date))); }
    function _get_values($data, $key, $values) {
        $values = explode(',', trim($values, '[]'));
        $i = 0;
        $val = [];
        foreach($data as $k => $v) {
            if (str_starts_with($k, $key)) {
                
                if ($data[$k]) $val[] = $values[$i];
                $i++;
            }
        }
        return $val;
    }
    function cb_values($data, $key, $values) {
        return '['.implode(',', _get_values($data, $key, $values)).']';
    }
    function radio_value($data, $key, $values) {
        return @trim(_get_values($data, $key, $values)[0], '"');
    }
    
    // ... (définition de fonctions pour la manipulation des données)
    try {
        $pdo = new PDO($db_host, $db_user, $db_pass);
        // $pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, false);

        // Vidage des tables si $truncate_tables est vrai
        if ($truncate_tables) {
            $pdo->query("TRUNCATE TABLE glpi_plugin_formcreator_formanswers");
            $pdo->query("TRUNCATE TABLE glpi_plugin_formcreator_answers");
        }

        // Ouverture du fichier CSV pour lecture
        $fp = fopen($_FILES['import_file_1']['tmp_name'], 'r');
        $nlig = 0;
        $lastInsertId = 0;

        // Boucle de lecture des lignes du fichier CSV
        while ($line = fgetcsv($fp, 2000, ';')) {
            // Traitement différent pour la première ligne (titres)
            if ($nlig == 0) {
                // ... (traitement des titres)
                $titres = $line;
                $titres[0] = "date_signalement"; // TODO remove BOM
            } else {
                // ... (traitement des données et insertion dans la base de données)
                $data = array_combine($titres, $line);
                
                $date = date('Y-m-d H:i:s');
                $sql = "INSERT INTO `glpi_plugin_formcreator_formanswers` (`name`, `entities_id`, `is_recursive`, `plugin_formcreator_forms_id`, `requester_id`, `users_id_validator`, `groups_id_validator`, `request_date`, `status`, `comment`) VALUES
                            ('Signalement de dysfonctionnement', 0, 0, 1, 2, 0, 0, '$date', 103, '')";
                $pdo->query($sql);
                $lastInsertId = $pdo->lastInsertId();
                
                $sql = 'SELECT s.id s_id, s.name s_name, q.id q_id, q.name q_name, q.values q_values, fieldtype
                        FROM glpi_plugin_formcreator_questions q
                        JOIN glpi_plugin_formcreator_sections s ON s.id = q.plugin_formcreator_sections_id
                        WHERE s.plugin_formcreator_forms_id = 1
                        ORDER BY s.order, q.row';
                $res1 = $pdo->query($sql);

                foreach($res1 as $row1) {
                    $value = "----------------------";
                    // echo ("$row1[s_name]:$row1[q_name]").': '; // utf8_encode
                    switch(("$row1[s_name]:$row1[q_name]")) {
                        case "Signalement de dysfonctionnement:Date du signalement":                       $value = dateFr2Ansi($data['date_signalement']); break;
                        case "Déposé par:Nom":                                                             $value = $data['depose_par_nom']; break;
                        case "Déposé par:Prénom":                                                          $value = $data['depose_par_prenom']; break;
                        case "Déposé par:Fonction":                                                        $value = $data['depose_par_fonction']; break;
                        case "Sous couvert de:Nom":                                                        $value = $data['sous_couvert_de_nom']; break;
                        case "Sous couvert de:Prénom":                                                     $value = $data['sous_couvert_de_prenom']; break;
                        case "Sous couvert de:Fonction":                                                   $value = $data['sous_couvert_de_fonction']; break;
                        case "Personne à contacter:Nom":                                                   $value = $data['personne_a_contacter_nom']; break;
                        case "Personne à contacter:Prénom":                                                $value = $data['personne_a_contacter_prenom']; break;
                        case "Personne à contacter:Fonction":                                              $value = $data['personne_a_contacter_fonction']; break;
                        case "Personne à contacter:Courriel":                                              $value = $data['personne_a_contacter_courriel']; break;
                        case "Personne à contacter:Téléphone(s)":                                          $value = $data['personne_a_contacter_telephones']; break;
                        case "Localisation du dysfonctionnement:Bâtiment":                                 $value = cb_values($data, 'batiment', $row1['q_values']); break;
                        case "Localisation du dysfonctionnement:Niveau":                                   $value = cb_values($data, 'niveau', $row1['q_values']); break;
                        case "Localisation du dysfonctionnement:Description précise du dysfonctionnement": $value = $data['description']; break;
                        case "Localisation du dysfonctionnement:Niveau d impact sur l activité":           $value = radio_value($data, 'impact', $row1['q_values']); break;
                        case "Localisation du dysfonctionnement:Qualification du dysfonctionnement":       $value = radio_value($data, 'qualification', $row1['q_values']); break;
                        case "Localisation du dysfonctionnement:Date du constat de dysfonctionnement":     $value = dateFr2Ansi($data['date_constat']); break;
                        case "Localisation du dysfonctionnement:Visa du demandeur":                        $value = cb_values($data, 'visa_demandeur', $row1['q_values']); break;
                        case "Localisation du dysfonctionnement:Visa Direction ou Service":                $value = cb_values($data, 'visa_direction', $row1['q_values']); break;
                        case "Partie réservée au BMO:N° demande":                                          $value = $data['numero_demande']; break;
                        case "Partie réservée au BMO:Signalement reçu le":                                 $value = dateFr2Ansi($data['date_reception']); break;
                        case "Partie réservée au BMO:Caractérisation de la demande":                       $value = radio_value($data, 'caracterisation', $row1['q_values']); break;
                        case "Partie réservée au BMO:Prise en charge apportée":                            $value = radio_value($data, 'prise_en_charge', $row1['q_values']); break;
                        case "Partie réservée au BMO:Référent de la prise en charge":                      $value = radio_value($data, 'referent_pec', $row1['q_values']); break;
                        case "Partie réservée au BMO:Observations":                                        $value = $data['observations']; break;
                        case "Partie réservée au BMO:Signalement clôturé le":                              $value = dateFr2Ansi($data['date_cloture']); break;
                    }
                    $value = $pdo->quote($value);
                    // echo "($lastInsertId, $row1[q_id], $value)".PHP_EOL;

                    $sql = "INSERT INTO `glpi_plugin_formcreator_answers` (`plugin_formcreator_formanswers_id`, `plugin_formcreator_questions_id`, `answer`) VALUES
                            ($lastInsertId, $row1[q_id], $value)";
                    $pdo->query($sql);

                }
            }
            echo PHP_EOL;
            $nlig++;
        }
        sleep(1);
        die;


        // ... (autres requêtes SQL)
        $sql = 'SELECT id, name FROM glpi_plugin_formcreator_sections WHERE plugin_formcreator_forms_id = 1 ORDER BY id';
        $res = $pdo->query($sql);
        foreach ($res as $row) {
            echo utf8_encode($row['id'].' '.$row['name']).PHP_EOL;
        }
        echo '<hr/>';
        
        // select id, name, plugin_formcreator_sections_id, fieldtype, `values`, row, col, width from glpi_plugin_formcreator_questions;
        
        // ... (autres requêtes SQL et manipulations de données)
        $sql = 'SELECT * FROM glpi_plugin_formcreator_formanswers WHERE plugin_formcreator_forms_id = 1 ORDER BY id';
        // name = Signalement de dysfonctionnement
        // plugin_formcreator_forms_id = 1
        // requester_id = 2
        // users_id_validator = 0
        // groups_id_validator = 0
        // request_date = now
        // status = 103
        // comment = <empty>
        
/*

        SELECT q.*
        FROM glpi_plugin_formcreator_questions q
        JOIN glpi_plugin_formcreator_sections s ON s.id = q.plugin_formcreator_sections_id
        WHERE s.plugin_formcreator_forms_id = 1

*/

        $sql = 'SELECT s.*, q.id, q.name, q.fieldtype, q.values
                FROM glpi_plugin_formcreator_questions q
                JOIN glpi_plugin_formcreator_sections s ON s.id = q.plugin_formcreator_sections_id
                WHERE s.plugin_formcreator_forms_id = 1';
        $res = $pdo->query($sql);
        foreach ($res as $row) {
            echo utf8_encode($row['id'].' '.$row['name'].' '.$row['fieldtype'].' '.$row['values']).PHP_EOL;
        }
        echo '<hr/>';
        
        
        
        $sql = 'SELECT * FROM glpi_plugin_formcreator_questions';


        $sql = 'SELECT * FROM glpi_plugin_formcreator_answers';
        
        
        // glpi_plugin_formcreator_answers
        $sql =
            'SELECT * FROM glpi_plugin_formcreator_answers ans
            JOIN glpi_plugin_formcreator_sections sec ON sec.id = ans.plugin_formcreator_questions_id
            ';
    } catch (\Exception $e) {
        print_r($e);
    }
        
/*
truncate table glpi_plugin_formcreator_sections;
truncate table glpi_plugin_formcreator_questions;
truncate tableglpi_plugin_formcreator_formanswers
truncate table glpi_plugin_formcreator_answers;
truncate table glpi_plugin_formcreator_forms;

*/        
        
       