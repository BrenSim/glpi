<?php

require_once "vendor/autoload.php";
require __DIR__ . '/vendor/autoload.php';
include 'config.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

use GuzzleHttp\Client;

function SendMail($htmlContent, $recipient, $reportDate)
{

    $mail = new PHPMailer(true);

    try {
        // Paramètres du serveur SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp-relay.brevo.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'support_smtp@softia.fr';
        $mail->Password = 'ncy750BUv3aFHW8L';
        $mail->SMTPAutoTLS = false;
        $mail->Port = 587;
        $mail->CharSet = 'UTF-8';

        // Destinataire, sujet et corps de l'e-mail
        $mail->setFrom('noreply@softia.fr', 'Equipe DEA');
        $mail->addAddress($recipient);
        $mail->Subject = "Signalement n° du " . $reportDate;
        $mail->addReplyTo('noreply@softia.fr', 'noreply@softia.fr');
        $mail->msgHTML($htmlContent);
        // $mail->addStringAttachment($fileContent, $fileName);
        
        // Envoi de l'e-mail
        $mail->send();
        echo 'L\'e-mail a été envoyé avec succès.';
    } catch (Exception $e) {
        echo "Une erreur s'est produite lors de l'envoi de l'e-mail : {$mail->ErrorInfo}";
    }
    
}
