<?php
// Fonctions pour GLPI DEA 93
// ARR 08/04/2024

// ID section BMO
function getIdSectionBMO()
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['id'],
      'FROM' => 'glpi_plugin_formcreator_sections',
      'WHERE' => ['name' => ['LIKE', '%BMO%']]
  ]);
  return $iterator->current()['id'] ?? null;
}

// ID section validation
function getIdSectionValideur()
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['id'],
      'FROM' => 'glpi_plugin_formcreator_sections',
      'WHERE' => ['name' => ['LIKE', '%validation%']]
  ]);
  return $iterator->current()['id'] ?? null;
}

// ARR 16/04/2024
function getIdNomValideur()
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['id'],
      'FROM' => 'glpi_plugin_formcreator_questions',
      'WHERE' => ['plugin_formcreator_sections_id' => getIdSectionValideur(), 'fieldtype' => 'text']
  ]);
  return $iterator->current()['id'] ?? null;
}

function getIdVisaValideur()
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['id'],
      'FROM' => 'glpi_plugin_formcreator_questions',
      'WHERE' => ['plugin_formcreator_sections_id' => getIdSectionValideur(), 'fieldtype' => 'checkboxes']
  ]);
  return $iterator->current()['id'] ?? null;
}

function viserFormulaire()
{
  include('config.php');
  $user_name = $_SESSION['glpifirstname']." ".$_SESSION['glpirealname'];
  $pdo = new PDO($db_host, $db_user, $db_pass);
  $sql = "UPDATE glpi_plugin_formcreator_answers SET answer = ? WHERE plugin_formcreator_formanswers_id = ? AND plugin_formcreator_questions_id = ?";
  $stmt = $pdo->prepare($sql);
  $stmt->execute(['["Viser"]', $_SESSION['id_answer'], getIdVisaValideur()]);
  $stmt->execute([$user_name, $_SESSION['id_answer'], getIdNomValideur()]);
  $stmt = null;
  $pdo = null;
  
  /*global $DB;
  $DB->update([
      'glpi_plugin_formcreator_answers',
      ['answer' => '["Viser"]'],
      ['glpi_plugin_formcreator_answers_id' => $_SESSION['id_answer'], 'glpi_plugin_formcreator_answers' => getIdVisaValideur()]
  ]);*/
}

function getUserGroups()
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['groups.name as group_name'],
      'FROM' => 'glpi_groups_users AS groups_users',
      'JOIN' => [
        'glpi_groups AS groups' => [
           'ON' => [
              'groups' => 'id',
              'groups_users' => 'groups_id',
           ]
        ]
      ],
      'WHERE' => ['users_id' => $_SESSION['glpiID']]
  ]);
  $groups = []; foreach ($iterator as $row) {
    if ($row['group_name'] == 'Demandeur') $groups[] = 'demandeur';
    if ($row['group_name'] == 'Direction/Service (validation)') $groups[] = 'valideur';
  }
  return $groups;
}

function isDemandeur()
{
  return in_array('demandeur', getUserGroups());
}

function isValideur()
{
  return in_array('valideur', getUserGroups());
}

// Récupération des questions d'un formulaire
function getQuestions($idForm = 1)
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['plugin_formcreator_forms_id AS id_form', 'section.id AS id_section', 'question.id AS id_question', 'fieldtype'],
      'FROM' => 'glpi_plugin_formcreator_sections AS section',
      'JOIN' => [
        'glpi_plugin_formcreator_questions AS question' => [
           'ON' => [
              'question' => 'plugin_formcreator_sections_id',
              'section' => 'id',
           ]
        ]
      ],
      'WHERE' => [
        'plugin_formcreator_forms_id' => $idForm,
      ]
  ]);
  $questions = []; foreach ($iterator as $row) $questions[$row['id_question']] = $row;
  return $questions;
}

// Récupération des données du demandeur
function getAnswers($idAnswer = 0)
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['plugin_formcreator_formanswers_id AS id_answer', 'plugin_formcreator_questions_id AS id_question', 'plugin_formcreator_sections_id AS id_section', 'answer', 'fieldtype'],
      'FROM' => 'glpi_plugin_formcreator_answers AS answer',
      'JOIN' => [
        'glpi_plugin_formcreator_questions AS question' => [
           'ON' => [
              'answer' => 'plugin_formcreator_questions_id',
              'question' => 'id',
           ]
        ]
      ],
      'WHERE' => [
        'plugin_formcreator_formanswers_id' => $idAnswer,
        // 'plugin_formcreator_sections_id' => ['<>', getIdSectionBMO()],
      ]
  ]);
  $answers = []; foreach ($iterator as $row) $answers[$row['id_question']] = $row;
  return $answers;
}

// Récupération identifiant question à partir de son nom
function getIdQuestionByName($questionName = '')
{
  global $DB;
  $iterator = $DB->request([
      'SELECT' => ['id'],
      'FROM' => 'glpi_plugin_formcreator_questions',
      'WHERE' => [
        'name' => $questionName,
      ],
      'ORDERBY' => [
        'plugin_formcreator_sections_id'
    ]
  ]);
  $answers = []; foreach ($iterator as $row) $answers[] = $row;
  return count($answers)>0 ? $answers : [['id'=>'0']] ;
}
?>