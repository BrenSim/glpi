<?php
require __DIR__ . '/vendor/autoload.php';
require_once 'functions-dea93.php';
// Inclusion du fichier de configuration contenant les informations de connexion à la base de données
include 'config.php';
// Inclure les fichiers nécessaires du framework GLPI
include ("../../inc/includes.php");

use setasign\Fpdi\Fpdi;

function getEmailsMembersGroupByGroupName($groupName) {
    global $DB;
    
    // Récupérer l'identifiant du groupe à partir de son nom
    $group = new Group();
    $group->getFromDBByCrit(['name' => $groupName]);
    $groupId = $group->getID();
    $allMail = [];
    if ($groupId) {
        // Récupérer les membres du groupe
        $members = $DB->request([
            'FROM'    => 'glpi_groups_users',
            'WHERE'   => ['groups_id' => $groupId]
        ]);

        if ($members->numrows() > 0) {
            foreach ($members as $member) {
                $userEmail = new UserEmail();
                $allMail[] = $userEmail->getAllForUser($member['users_id']);
            }
        }
    }
    return $allMail;
}

// Récupérer les données envoyées en GET comme paramètres
$JSONTableSelectedValues = stripslashes($_GET['selectedValues']);
$selectedFormResult = json_decode($JSONTableSelectedValues, true);

// Récupération des données
// Connexion à la base de données en utilisant PDO avec les informations fournies dans 'config.php'
$pdo = new PDO($db_host, $db_user, $db_pass);

// Requête SQL pour récupérer certaines informations depuis la base de données
$res = $pdo->query("SELECT s.id s_id, s.name s_name, q.id q_id, q.name q_name, q.values q_values, fieldtype
FROM glpi_plugin_formcreator_questions q
JOIN glpi_plugin_formcreator_sections s ON s.id = q.plugin_formcreator_sections_id
WHERE s.plugin_formcreator_forms_id = 1
ORDER BY s.order, q.row;");

// Initialisation d'un tableau pour stocker les questions récupérées
$questions = [];

// Boucle parcourant chaque résultat de la requête et organisant les données dans un tableau
foreach ($res as $key => $row) {
    foreach ($row as $k => $v) {
        // Encodage UTF-8 si la valeur n'est pas nulle
        if ($v != null) {
            $v = utf8_encode($v);
        }

        // Décodage JSON si la clé est 'q_values' et si le champ est de type 'radios' ou 'checkboxes'
        if ($k == 'q_values' && in_array($row['fieldtype'], array('radios', 'checkboxes'))) {
            $v = json_decode($v);
        }

        $row[$k] = $v;
    }
    $questions[$row['q_id']] = $row;
}

// Requête pour récupérer d'autres informations depuis la base de données
$res = $pdo->query("SELECT plugin_formcreator_formanswers_id f_id, plugin_formcreator_questions_id q_id, answer
                        FROM glpi_plugin_formcreator_answers a
                        JOIN glpi_plugin_formcreator_questions q ON q.id = a.plugin_formcreator_questions_id
                        JOIN glpi_plugin_formcreator_sections s ON s.id = q.plugin_formcreator_sections_id
                        ORDER BY f_id, s.order, q.row;");

$arrayResult = $res->fetchAll();

$formsData = [];
foreach ($arrayResult as $r => $i) {
    if (in_array($i["f_id"], $selectedFormResult)) {
        $formsData[$i["f_id"]][$i["q_id"]] = $i['answer'];
    }
}

// Identifiant de chaque réponse:
// 1=> Signalement de dysfonctionnement
// 2=> Déposé par Nom
// 3=> Déposé par Prénom
// 4=> Déposé par Fonction
// 5=> Sous couvert de Nom
// 6=> Sous couvert de Prénom
// 7=> Sous couvert de Fonction
// 8=> Personne à contacter Nom
// 9=> Personne à contacter Prénom
// 10=> Personne à contacter Fonction
// 11=> Personne à contacter Courriel
// 12=> Personne à contacter Téléphone
// 13=> Localisation du dysfonctionnement Bâtiment
// 14=> Localisation du dysfonctionnement Niveau
// 15=> Localisation du dysfonctionnement Description précise du dysfonctionnement
// 16=> Localisation du dysfonctionnement Niveau d impact sur l activité
// 17=> Localisation du dysfonctionnement Qualification du dysfonctionnement
// 24=> Localisation du dysfonctionnement Date du constat de dysfonctionnement
// 25=> Localisation du dysfonctionnement Visa du demandeur
// 26=> Localisation du dysfonctionnement Visa Direction ou Service
// 18=> Signalement reçu le
// 19=> Caractérisation de la demande
// 20=> Prise en charge apportée
// 21=> Référent de la prise en charge
// 22=> Observations
// 23=> Signalement clôturé le

// Créer une archive ZIP pour le cas où on exporte plusieurs fichiers
function createZip($allPdfContent, $zipName, $allPdfFileName) {
    // Création d'une instance de la classe ZipArchive
    $zip = new ZipArchive();
    // Ouverture de l'archive avec le nom spécifié
    if ($zip->open($zipName, ZipArchive::CREATE) === TRUE) {
        // Ajout de chaque contenu PDF au zip
        foreach ($allPdfContent as $index => $pdfContent) {
            $fileName = $index. "-" .$allPdfFileName[$index];
            // Ajout du contenu PDF au zip avec un nom de fichier unique
            $zip->addFromString($fileName, $pdfContent);
        }
        // Fermeture de l'archive
        $zip->close();
        return true;
    } else {
        return false;
    }
}

$allPdfContent = array();
$allPdfFileName = array();
//Création des fichiers pdf selon les nombres des données de réponses
if (count($formsData) > 0) {
    $mail[0] = getEmailsMembersGroupByGroupName("courriel_responsable");
    $firstMail = 'rschmidt@seinesaintdenis.fr';
    $secondMail = 'acosteleanu@seinesaintdenis.fr';
    $thirdMail = 'njebahichaumat@seinesaintdenis.fr';
    // Gérer les 3 mails à afficher dans le pdf
    if (count($mail[0]) >= 3) {
        $mail = array_slice($mail, 0, 3);
        $firstMail = $mail[0][0][0];
        $secondMail = $mail[0][1][0];
        $thirdMail = $mail[0][2][0];
    }
    
    foreach ($formsData as $i => $value) {

        // initialiser FPDI
        $pdf = new FPDI();
        // Récuperer le nombre de page
        $pageCount = $pdf->setSourceFile('Signalement dysfonctionement DEAGD.pdf');
        // $data = [];
        for ($pageNo = 1; $pageNo <= $pageCount; $pageNo++) {
            // importer la page
            $templateId = $pdf->importPage($pageNo);
            // récupère la taille de la page importée
            $size = $pdf->getTemplateSize($templateId);
            $pdf->AddPage($size['orientation'], array($size['width'], $size['height']));

            $pdf->useTemplate($templateId);
            $pdf->SetFont('Helvetica');

            //Ajout text sur les pages
            if ($pageNo == 1) {
                // Par courriel à
                $pdf->SetXY(86.5, 76.5);
                $pdf->SetTextColor(0, 0, 255);
                $pdf->SetFont('', 'U');
                $pdf->Write(8, $firstMail);

                // Copie à
                $pdf->SetXY(86.5, 85);
                $pdf->Write(8, $secondMail);
                $pdf->SetFont('', '');
                $pdf->SetTextColor(0, 0, 0);
                $pdf->Write(8, " ;");

                $pdf->SetTextColor(0, 0, 255);
                $pdf->SetFont('', 'U');
                $pdf->SetXY(86.5, 93);
                $pdf->Write(8, $thirdMail);


                //N° demande
                // Réinitialiser la couleur du texte et le style du texte
                $pdf->SetTextColor(0, 0, 0);
                $pdf->SetFont('', '');
                $pdf->SetXY(140, 111);
                $pdf->Write(8, $formsData[$i][getIdQuestionByName('N° demande')[0]['id']]);

                //Signalé le
                $pdf->SetXY(135, 139);
                $pdf->Write(8, date('d/m/Y', strtotime($formsData[$i][getIdQuestionByName('Date du signalement')[0]['id']])));

                //Déposé par
                $pdf->SetXY(24.5, 173);
                $pdf->Write(7, utf8_decode($formsData[$i][getIdQuestionByName('Nom')[0]['id']]));

                $pdf->SetXY(86.5, 173);
                $pdf->Write(7, utf8_decode($formsData[$i][getIdQuestionByName('Prénom')[0]['id']]));

                $pdf->SetXY(136.5, 173);
                $pdf->Write(7, utf8_decode($formsData[$i][getIdQuestionByName('Fonction')[0]['id']]));

                //Sous couvert de
                $pdf->SetXY(24.5, 200);
                $pdf->Write(7, utf8_decode($formsData[$i][getIdQuestionByName('Nom')[1]['id']]));

                $pdf->SetXY(86.5, 200);
                $pdf->Write(7, utf8_decode($formsData[$i][getIdQuestionByName('Prénom')[1]['id']]));

                $pdf->SetXY(136.5, 200);
                $pdf->Write(7, utf8_decode($formsData[$i][getIdQuestionByName('Fonction')[1]['id']]));

                //Personne à contacter
                $pdf->SetXY(24.5, 227);
                $pdf->Write(7, utf8_decode($formsData[$i][getIdQuestionByName('Nom')[2]['id']]));

                $pdf->SetXY(86.5, 227);
                $pdf->Write(7, utf8_decode($formsData[$i][getIdQuestionByName('Prénom')[2]['id']]));

                $pdf->SetXY(136.5, 227);
                $pdf->Write(7, utf8_decode($formsData[$i][getIdQuestionByName('Fonction')[2]['id']]));

                $pdf->SetXY(24.5, 240);
                $pdf->Write(7, utf8_decode($formsData[$i][getIdQuestionByName('Courriel')[0]['id']]));

                $pdf->SetXY(86.5, 240);
                $pdf->Write(7, utf8_decode($formsData[$i][getIdQuestionByName('Téléphone(s)')[0]['id']]));
            }

            if ($pageNo == 2) {
                //Bâtiment
                //Cocher E
                $pdf->SetXY(26.5, 56.5);
                $pdf->SetFont('ZapfDingbats', '', 13);
                if (str_contains($formsData[$i][getIdQuestionByName('Bâtiment')[0]['id']], "E")) {
                    $pdf->Write(8, '4');
                }

                //Cocher F
                $pdf->SetXY(57, 56.5);
                if (str_contains($formsData[$i][getIdQuestionByName('Bâtiment')[0]['id']], "F")) {
                    $pdf->Write(8, '4');
                }

                //Cocher G
                $pdf->SetXY(91, 56.5);
                if (str_contains($formsData[$i][getIdQuestionByName('Bâtiment')[0]['id']], "G")) {
                    $pdf->Write(8, '4');
                }

                //Cocher H
                $pdf->SetXY(123.5, 56.5);
                if (str_contains($formsData[$i][getIdQuestionByName('Bâtiment')[0]['id']], "H")) {
                    $pdf->Write(8, '4');
                }

                //Cocher I
                $pdf->SetXY(156, 56.5);
                if (str_contains($formsData[$i][getIdQuestionByName('Bâtiment')[0]['id']], "I")) {
                    $pdf->Write(8, '4');
                }

                //Cocher Site
                $pdf->SetXY(26.5, 63);
                if (str_contains($formsData[$i][getIdQuestionByName('Bâtiment')[0]['id']], "Site")) {
                    $pdf->Write(8, '4');
                }

                //Cocher Cour Haute
                $pdf->SetXY(57, 63);
                if (str_contains($formsData[$i][getIdQuestionByName('Bâtiment')[0]['id']], "Cour")) {
                    $pdf->Write(8, '4');
                }

                //Cocher Espace vert
                $pdf->SetXY(91, 63);
                if (str_contains($formsData[$i][getIdQuestionByName('Bâtiment')[0]['id']], "Espace vert")) {
                    $pdf->Write(8, '4');
                }

                //Cocher Parking DEA
                $pdf->SetXY(123.5, 63);
                if (str_contains($formsData[$i][getIdQuestionByName('Bâtiment')[0]['id']], "Parking DEA")) {
                    $pdf->Write(8, '4');
                }

                //Cocher Parking visiteur
                $pdf->SetXY(156, 63);
                if (str_contains($formsData[$i][getIdQuestionByName('Bâtiment')[0]['id']], "Parking DEA")) {
                    $pdf->Write(8, '4');
                }

                // Niveau
                //Cocher Sous sol-3
                $pdf->SetXY(26.5, 84);
                if (str_contains($formsData[$i][getIdQuestionByName('Niveau')[0]['id']], "Sous-sol -3")) {
                    $pdf->Write(8, '4');
                }

                //Cocher Sous sol-2
                $pdf->SetXY(57, 84);
                if (str_contains($formsData[$i][getIdQuestionByName('Niveau')[0]['id']], "Sous-sol -2")) {
                    $pdf->Write(8, '4');
                }

                //Cocher Sous sol-1
                $pdf->SetXY(91, 84);
                if (str_contains($formsData[$i][getIdQuestionByName('Niveau')[0]['id']], "Sous-sol -1")) {
                    $pdf->Write(8, '4');
                }

                //Cocher Cour basse
                $pdf->SetXY(123.5, 84);
                if (str_contains($formsData[$i][getIdQuestionByName('Niveau')[0]['id']], "Cour basse")) {
                    $pdf->Write(8, '4');
                }

                //Cocher Cour haute
                $pdf->SetXY(156, 84);
                if (str_contains($formsData[$i][getIdQuestionByName('Niveau')[0]['id']], "Cour haute")) {
                    $pdf->Write(8, '4');
                }

                //Cocher RdC
                $pdf->SetXY(26.5, 90.5);
                if (str_contains($formsData[$i][getIdQuestionByName('Niveau')[0]['id']], "RdC")) {
                    $pdf->Write(8, '4');
                }

                //Cocher 1er
                $pdf->SetXY(57, 90.5);
                if (str_contains($formsData[$i][getIdQuestionByName('Niveau')[0]['id']], "1er")) {
                    $pdf->Write(8, '4');
                }

                //Cocher 2ème
                $pdf->SetXY(91, 90.5);
                if (str_contains($formsData[$i][getIdQuestionByName('Niveau')[0]['id']], "2ème")) {
                    $pdf->Write(8, '4');
                }

                //Cocher Toiture
                $pdf->SetXY(123.5, 90.5);
                if (str_contains($formsData[$i][getIdQuestionByName('Niveau')[0]['id']], "Toiture")) {
                    $pdf->Write(8, '4');
                }

                //Cocher Terrasse
                $pdf->SetXY(26.5, 98.5);
                if (str_contains($formsData[$i][getIdQuestionByName('Niveau')[0]['id']], "Terrasse")) {
                    $pdf->Write(8, '4');
                }

                //Cocher Palier
                $pdf->SetXY(57, 98.5);
                if (str_contains($formsData[$i][getIdQuestionByName('Niveau')[0]['id']], "Palier")) {
                    $pdf->Write(8, '4');
                }

                //Cocher Extérieur
                $pdf->SetXY(91, 98.5);
                if (str_contains($formsData[$i][getIdQuestionByName('Niveau')[0]['id']], "Extérieur")) {
                    $pdf->Write(8, '4');
                }

                //Description précise du dysfonctionnement
                $pdf->SetXY(26.5, 128);
                $pdf->SetFont('Helvetica');
                // $descriptionText = $formsData[$i][getIdQuestionByName('Description précise du dysfonctionnement')[0]['id']]?? utf8_encode($formsData[$i][getIdQuestionByName('Description précise du dysfonctionnement')[0]['id']]);
                // $pdf->Write(8, strip_tags($descriptionText));
                $pdf->MultiCell(150, 7, utf8_decode($formsData[$i][getIdQuestionByName('Description précise du dysfonctionnement')[0]['id']]));

                //Niveau d'impact
                //Cocher Faible
                $pdf->SetXY(26.5, 201);
                $pdf->SetFont('ZapfDingbats', '', 13);
                if (str_contains($formsData[$i][getIdQuestionByName('Niveau d impact sur l activité')[0]['id']], "Faible")) {
                    $pdf->Write(8, '4');
                }

                //Cocher Moyen
                $pdf->SetXY(54.5, 201);
                if (str_contains($formsData[$i][getIdQuestionByName('Niveau d impact sur l activité')[0]['id']], "Moyen")) {
                    $pdf->Write(8, '4');
                }

                //Cocher Elevé
                $pdf->SetXY(82.5, 201);
                if (str_contains($formsData[$i][getIdQuestionByName('Niveau d impact sur l activité')[0]['id']], "Elevé")) {
                    $pdf->Write(8, '4');
                }

                //Cocher Très Elevé
                $pdf->SetXY(35, 216);
                if (str_contains($formsData[$i][getIdQuestionByName('Niveau d impact sur l activité')[0]['id']], "Très Elevé")) {
                    $pdf->Write(8, '4');
                }

                //Cocher Rédhibitoire
                $pdf->SetXY(68, 216);
                if (str_contains($formsData[$i][getIdQuestionByName('Niveau d impact sur l activité')[0]['id']], "Rédhibitoire")) {
                    $pdf->Write(8, '4');
                }

                //Qualification du dysfonctionnement
                //Cocher Informative
                $pdf->SetXY(108.5, 201);
                if (str_contains($formsData[$i][getIdQuestionByName('Qualification du dysfonctionnement')[0]['id']], "Informative")) {
                    $pdf->Write(8, '4');
                }

                //Cocher Importante
                $pdf->SetXY(136.5, 201);
                if (str_contains($formsData[$i][getIdQuestionByName('Qualification du dysfonctionnement')[0]['id']], "Importante")) {
                    $pdf->Write(8, '4');
                }

                //Cocher Critique
                $pdf->SetXY(164.5, 201);
                if (str_contains($formsData[$i][getIdQuestionByName('Qualification du dysfonctionnement')[0]['id']], "Critique")) {
                    $pdf->Write(8, '4');
                }

                //Date du constat de dysfonctionnement
                $pdf->SetXY(135, 235);
                $pdf->SetFont('Helvetica');
                $pdf->Write(8, date('d/m/Y', strtotime($formsData[$i][getIdQuestionByName('Date du constat de dysfonctionnement')[0]['id']])));

                $pdf->SetFont('ZapfDingbats', '', 13);
                //Visa du demandeur
                $pdf->SetXY(27.5, 249.5);
                if (str_contains($formsData[$i][getIdQuestionByName("Visa du demandeur")[0]['id']], "Viser")) {
                    $pdf->Write(8, '4');
                }

                //Visa Direction ou service
                $pdf->SetXY(109.5, 249.5);
                if (str_contains($formsData[$i][getIdQuestionByName("Visa Direction ou Service")[0]['id']], "Viser")) {
                    $pdf->Write(8, '4');
                }
                $pdf->SetFont('Helvetica');
            }

            if ($pageNo == 3) {
                //Signalement reçu le
                $pdf->SetXY(67, 41);
                $signalementDate = $formsData[$i][getIdQuestionByName("Signalement reçu le")[0]['id']] != '' ? date('d/m/Y', strtotime($formsData[$i][getIdQuestionByName("Signalement reçu le")[0]['id']])) :'';
                $pdf->Write(8, $signalementDate);

                //Caractérisation de la demande
                //Cocher GPA
                $pdf->SetXY(50.5, 63.5);
                $pdf->SetFont('ZapfDingbats', '', 13);
                if (str_contains($formsData[$i][getIdQuestionByName("Caractérisation de la demande")[0]['id']], "GPA")) {
                    $pdf->Write(8, '4');
                }

                //Cocher Maintenance Exploitation
                $pdf->SetXY(50.5, 70);
                if (str_contains($formsData[$i][getIdQuestionByName("Caractérisation de la demande")[0]['id']], "Maintenance Exploitation")) {
                    $pdf->Write(8, '4');
                }

                //Cocher PPI
                $pdf->SetXY(50.5, 78);
                if (str_contains($formsData[$i][getIdQuestionByName("Caractérisation de la demande")[0]['id']], "PPI")) {
                    $pdf->Write(8, '4');
                }

                //Prise en charge apportée
                //Cocher Ouverture de fiche GPA n°
                $pdf->SetXY(50.5, 93);
                if (str_contains($formsData[$i][getIdQuestionByName("Prise en charge apportée")[0]['id']], "GPA")) {
                    $pdf->Write(8, '4');
                }

                //Cocher Création d'une Demande d'Intervention TECHBASE
                $pdf->SetXY(50.5, 100);
                if (str_contains($formsData[$i][getIdQuestionByName("Prise en charge apportée")[0]['id']], "TECHBASE")) {
                    $pdf->Write(8, '4');
                }

                //Cocher Transmission d'une demande d'Intervention au SQUR
                $pdf->SetXY(50.5, 107);
                if (str_contains($formsData[$i][getIdQuestionByName("Prise en charge apportée")[0]['id']], "SQUR")) {
                    $pdf->Write(8, '4');
                }

                //Cocher Transmission pour inscription PPI/TMGR DBL ou DEA
                $pdf->SetXY(50.5, 114);
                if (str_contains($formsData[$i][getIdQuestionByName("Prise en charge apportée")[0]['id']], "DEA")) {
                    $pdf->Write(8, '4');
                }

                //Référent de la prise en charge
                //Cocher BMO/SIMO/DBL
                $pdf->SetXY(50.5, 129.5);
                if (str_contains($formsData[$i][getIdQuestionByName("Référent de la prise en charge")[0]['id']], "BMO\/SIMO\/DBL")) {
                    $pdf->Write(8, '4');
                }

                //Cocher BEX/SBD/DBL
                $pdf->SetXY(50, 136);
                if (str_contains($formsData[$i][getIdQuestionByName("Référent de la prise en charge")[0]['id']], "BEX\/SBD\/DBL")) {
                    $pdf->Write(8, '4');
                }

                //Cocher BPTM/SBD/DBL
                $pdf->SetXY(50.5, 144);
                if (str_contains($formsData[$i][getIdQuestionByName("Référent de la prise en charge")[0]['id']], "BPTM\/SBD\/DBL")) {
                    $pdf->Write(8, '4');
                }

                //Cocher BMT/SQUR/DEA
                $pdf->SetXY(50.5, 151);
                if (str_contains($formsData[$i][getIdQuestionByName("Référent de la prise en charge")[0]['id']], "BMT\/SQUR\/DEA")) {
                    $pdf->Write(8, '4');
                }

                //Observations
                $pdf->SetXY(25, 169);
                $pdf->SetFont('Helvetica');
                // $pdf->Write(8, strip_tags($formsData[$i][22]));
                $pdf->MultiCell(155, 7, utf8_decode($formsData[$i][getIdQuestionByName("Observations")[0]['id']]));

                //Signalement clôturé le
                $pdf->SetXY(68, 229);
                $signalementDate = $formsData[$i][getIdQuestionByName("Signalement clôturé le")[0]['id']] != '' ? date('d/m/Y', strtotime($formsData[$i][getIdQuestionByName("Signalement clôturé le")[0]['id']])) :'';
                $pdf->Write(8, $signalementDate);
            }

        }
        // Convetir la date en français
        $timestamp = strtotime($formsData[$i][getIdQuestionByName('Date du signalement')[0]['id']]);
        $dateFormatFr = date("d-m-Y", $timestamp);
        // Gérer le fichier pdf
        if(count($formsData) > 1){
            $allPdfContent[] = $pdf->Output('', 'S');
            $allPdfFileName[] = "Signalement_dysfonctionement_DEAGD-" . $dateFormatFr . ".pdf";
        }else{
            $pdfContent = $pdf->Output("", 'S');
            $fileName = "Signalement_dysfonctionement_DEAGD-" . $dateFormatFr . ".pdf";
            header('Content-Description: File Transfer');
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="'. $fileName . '"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . strlen($pdfContent));
            echo $pdfContent;
        }
    }
    $zipName = "Signalement_dysfonctionement_DEAGD.zip";
    if (count($formsData) > 1 && createZip($allPdfContent, $zipName, $allPdfFileName)) {
        // Définir les en-têtes pour indiquer qu'il s'agit d'un fichier ZIP à télécharger
        header('Content-Description: File Transfer');
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $zipName . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($zipName));
    
        // Envoyer le contenu de l'archive ZIP au navigateur pour téléchargement
        readfile($zipName);
    
        // Supprime l'archive ZIP après le téléchargement
        unlink($zipName);
    }
}else{
    return;
}
