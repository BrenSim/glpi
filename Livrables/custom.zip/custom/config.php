<?php
$db_host = "mysql:host=localhost;dbname=glpi;charset=utf8";
$db_user = "root";
$db_pass = "";
