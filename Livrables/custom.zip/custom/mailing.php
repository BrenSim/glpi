<?php
require __DIR__ . '/vendor/autoload.php';
require_once 'sendMail.php';
// Inclusion du fichier de configuration contenant les informations de connexion à la base de données
include 'config.php';

use setasign\Fpdi\Fpdi;

$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https://" : "http://";

// Récupérez le nom de domaine
$domain = $_SERVER['HTTP_HOST'];

// Générer l'URL complète
$urlLogo = $protocol . $domain . '/glpi/plugins/custom/img/logo.png';

// Récupérer les données envoyées en POST comme paramètres
$selectedFormResult = json_decode($_POST['selectedValuesFormsResponse'], true);

// Récupération des données
// Connexion à la base de données en utilisant PDO avec les informations fournies dans 'config.php'
$pdo = new PDO($db_host, $db_user, $db_pass);

// // Requête SQL pour récupérer certaines informations depuis la base de données
// $res = $pdo->query("SELECT s.id s_id, s.name s_name, q.id q_id, q.name q_name, q.values q_values, fieldtype
// FROM glpi_plugin_formcreator_questions q
// JOIN glpi_plugin_formcreator_sections s ON s.id = q.plugin_formcreator_sections_id
// WHERE s.plugin_formcreator_forms_id = 1
// ORDER BY s.order, q.row;");

// // Initialisation d'un tableau pour stocker les questions récupérées
// $questions = [];

// // Boucle parcourant chaque résultat de la requête et organisant les données dans un tableau
// foreach ($res as $key => $row) {
//     foreach ($row as $k => $v) {
//         // Encodage UTF-8 si la valeur n'est pas nulle
//         if ($v != null) {
//             $v = utf8_encode($v);
//         }

//         // Décodage JSON si la clé est 'q_values' et si le champ est de type 'radios' ou 'checkboxes'
//         if ($k == 'q_values' && in_array($row['fieldtype'], array('radios', 'checkboxes'))) {
//             $v = json_decode($v);
//         }

//         $row[$k] = $v;
//     }
//     $questions[$row['q_id']] = $row;
// }

// // Requête pour récupérer d'autres informations depuis la base de données
// $res = $pdo->query("SELECT plugin_formcreator_formanswers_id f_id, plugin_formcreator_questions_id q_id, answer
//                         FROM glpi_plugin_formcreator_answers a
//                         JOIN glpi_plugin_formcreator_questions q ON q.id = a.plugin_formcreator_formanswers_id
//                         JOIN glpi_plugin_formcreator_sections s ON s.id = q.plugin_formcreator_sections_id
//                         ORDER BY f_id, s.order, q.row;");

// $arrayResult = $res->fetchAll();

// $formsData = [];
// foreach ($arrayResult as $r => $i) {
//     if(in_array($i["f_id"],$selectedFormResult)){
//         $formsData[$i["f_id"]][$i["q_id"]] = $i['answer'];
//     }
// }

// Identifiant de chaque réponse:
// 1=> Signalement de dysfonctionnement
// 2=> Déposé par Nom
// 3=> Déposé par Prénom
// 4=> Déposé par Fonction
// 5=> Sous couvert de Nom
// 6=> Sous couvert de Prénom
// 7=> Sous couvert de Fonction
// 8=> Personne à contacter Nom
// 9=> Personne à contacter Prénom
// 10=> Personne à contacter Fonction
// 11=> Personne à contacter Courriel
// 12=> Personne à contacter Téléphone
// 13=> Localisation du dysfonctionnement Bâtiment
// 14=> Localisation du dysfonctionnement Niveau
// 15=> Localisation du dysfonctionnement Description précise du dysfonctionnement
// 16=> Localisation du dysfonctionnement Niveau d impact sur l activité
// 17=> Localisation du dysfonctionnement Qualification du dysfonctionnement
// 24=> Localisation du dysfonctionnement Date du constat de dysfonctionnement
// 25=> Localisation du dysfonctionnement Visa du demandeur
// 26=> Localisation du dysfonctionnement Visa Direction ou Service
// 18=> Signalement reçu le
// 19=> Caractérisation de la demande
// 20=> Prise en charge apportée
// 21=> Référent de la prise en charge
// 22=> Observations
// 23=> Signalement clôturé le

//Création des fichiers pdf selon les nombres des données de réponses
// if (count($formsData) > 0) {
//     foreach ($formsData as $i => $value) {

        // // initialiser FPDI
        // $pdf = new FPDI();
        // // Récuperer le nombre de page
        // $pageCount = $pdf->setSourceFile('Signalement dysfonctionement DEAGD.pdf');
        // // $data = [];
        // for ($pageNo = 1; $pageNo <= $pageCount; $pageNo++) {
        //     // importer la page
        //     $templateId = $pdf->importPage($pageNo);
        //     // récupère la taille de la page importée
        //     $size = $pdf->getTemplateSize($templateId);
        //     $pdf->AddPage($size['orientation'], array($size['width'], $size['height']));

        //     $pdf->useTemplate($templateId);
        //     $pdf->SetFont('Helvetica');

        //     //Ajout text sur les pages
        //     if ($pageNo == 1) {
        //         //N° demande
        //         $pdf->SetXY(140, 111);
        //         $pdf->Write(8, $formsData[$i][30]);

        //         //Signalé le
        //         $pdf->SetXY(135, 139);
        //         $pdf->Write(8, date('d/m/Y', strtotime($formsData[$i][1])));

        //         //Déposé par
        //         $pdf->SetXY(24.5, 173);
        //         $pdf->Write(7, utf8_decode($formsData[$i][2]));

        //         $pdf->SetXY(79.5, 173);
        //         $pdf->Write(7, utf8_decode($formsData[$i][3]));

        //         $pdf->SetXY(140.5, 173);
        //         $pdf->Write(7, utf8_decode($formsData[$i][4]));

        //         //Sous couvert de
        //         $pdf->SetXY(24.5, 199);
        //         $pdf->Write(7, utf8_decode($formsData[$i][5]));

        //         $pdf->SetXY(79.5, 199);
        //         $pdf->Write(7, utf8_decode($formsData[$i][6]));

        //         $pdf->SetXY(140.5, 199);
        //         $pdf->Write(7, utf8_decode($formsData[$i][7]));

        //         //Personne à contacter
        //         $pdf->SetXY(24.5, 226);
        //         $pdf->Write(7, utf8_decode($formsData[$i][8]));

        //         $pdf->SetXY(79.5, 226);
        //         $pdf->Write(7, utf8_decode($formsData[$i][9]));

        //         $pdf->SetXY(140.5, 226);
        //         $pdf->Write(7, utf8_decode($formsData[$i][10]));

        //         $pdf->SetXY(37, 240);
        //         $pdf->Write(7, utf8_decode($formsData[$i][11]));

        //         $pdf->SetXY(116.5, 240);
        //         $pdf->Write(7, utf8_decode($formsData[$i][12]));
        //     }

        //     if ($pageNo == 2) {
        //         //Bâtiment
        //         //Cocher E
        //         $pdf->SetXY(25, 56);
        //         $pdf->SetFont('ZapfDingbats', '', 13);
        //         if (str_contains($formsData[$i][13], "E")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher F
        //         $pdf->SetXY(50, 56);
        //         if (str_contains($formsData[$i][13], "F")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher G
        //         $pdf->SetXY(76, 56);
        //         if (str_contains($formsData[$i][13], "G")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher H
        //         $pdf->SetXY(101, 56);
        //         if (str_contains($formsData[$i][13], "H")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher I
        //         $pdf->SetXY(126, 56);
        //         if (str_contains($formsData[$i][13], "I")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher Parking
        //         $pdf->SetXY(25, 64);
        //         if (str_contains($formsData[$i][13], "Parking")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher Cour
        //         $pdf->SetXY(62, 64);
        //         if (str_contains($formsData[$i][13], "Cour")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher Sous sol-2
        //         $pdf->SetXY(25, 82);
        //         if (str_contains($formsData[$i][14], "Sous-sol -2")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher Sous sol-1
        //         $pdf->SetXY(62, 82);
        //         if (str_contains($formsData[$i][14], "Sous-sol -1")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher Cour basse
        //         $pdf->SetXY(99, 82);
        //         if (str_contains($formsData[$i][14], "Cour basse")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher Cour haute
        //         $pdf->SetXY(136, 82);
        //         if (str_contains($formsData[$i][14], "Cour haute")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher RdC
        //         $pdf->SetXY(25, 90);
        //         if (str_contains($formsData[$i][14], "RdC")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher 1er
        //         $pdf->SetXY(62, 90);
        //         if (str_contains($formsData[$i][14], "1er")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher 2eme
        //         $pdf->SetXY(99, 90);
        //         if (str_contains($formsData[$i][14], "2ème")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher Terrasse
        //         $pdf->SetXY(125, 90);
        //         if (str_contains($formsData[$i][14], "Terrasse")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher Toiture
        //         $pdf->SetXY(162, 90);
        //         if (str_contains($formsData[$i][14], "Toiture")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Description précise du dysfonctionnement
        //         $pdf->SetXY(25, 120);
        //         $pdf->SetFont('Helvetica');
        //         $pdf->Write(8, strip_tags($formsData[$i][15]));

        //         //Niveau d'impact
        //         //Cocher Faible
        //         $pdf->SetXY(26, 204);
        //         $pdf->SetFont('ZapfDingbats', '', 13);
        //         if (str_contains($formsData[$i][16], "Faible")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher Moyen
        //         $pdf->SetXY(52, 204);
        //         if (str_contains($formsData[$i][16], "Moyen")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher Elevé
        //         $pdf->SetXY(77, 204);
        //         if (str_contains($formsData[$i][16], "Elevé")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher Très Elevé
        //         $pdf->SetXY(35, 216);
        //         if (str_contains($formsData[$i][16], "Très Elevé")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher Rédhibitoire
        //         $pdf->SetXY(68, 216);
        //         if (str_contains($formsData[$i][16], "Rédhibitoire")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Qualification du dysfonctionnement
        //         //Cocher Informative
        //         $pdf->SetXY(108, 204);
        //         if (str_contains($formsData[$i][17], "Informative")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher Importante
        //         $pdf->SetXY(133, 204);
        //         if (str_contains($formsData[$i][17], "Importante")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher Critique
        //         $pdf->SetXY(159, 204);
        //         if (str_contains($formsData[$i][17], "Critique")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Date du constat de dysfonctionnement
        //         $pdf->SetXY(135, 235);
        //         $pdf->SetFont('Helvetica');
        //         $pdf->Write(8, date('d/m/Y', strtotime($formsData[$i][24])));

        //         //Visa du demandeur
        //         $pdf->SetXY(27, 257);
        //         $pdf->Write(8, strip_tags($formsData[$i][25]));

        //         //Visa Direction ou service
        //         $pdf->SetXY(108, 257);
        //         $pdf->Write(8, strip_tags($formsData[$i][26]));
        //     }

        //     if ($pageNo == 3) {
        //         //Signalement reçu le
        //         $pdf->SetXY(67, 41);
        //         $pdf->Write(8, date('d/m/Y', strtotime($formsData[$i][18])));

        //         //Caractérisation de la demande
        //         //Cocher GPA
        //         $pdf->SetXY(51, 63);
        //         $pdf->SetFont('ZapfDingbats', '', 13);
        //         if (str_contains($formsData[$i][19], "GPA")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher Maintenance Exploitation
        //         $pdf->SetXY(51, 70);
        //         if (str_contains($formsData[$i][19], "Maintenance Exploitation")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher PPI
        //         $pdf->SetXY(51, 78);
        //         if (str_contains($formsData[$i][19], "PPI")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Prise en charge apportée
        //         //Cocher Ouverture de fiche GPA n°
        //         $pdf->SetXY(51, 93);
        //         if (str_contains($formsData[$i][20], "GPA")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher Création d'une Demande d'Intervention TECHBASE
        //         $pdf->SetXY(51, 100);
        //         if (str_contains($formsData[$i][20], "TECHBASE")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher Transmission d'une demande d'Intervention au SQUR
        //         $pdf->SetXY(51, 107);
        //         if (str_contains($formsData[$i][20], "SQUR")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher Transmission pour inscription PPI/TMGR DBL ou DEA
        //         $pdf->SetXY(51, 114);
        //         if (str_contains($formsData[$i][20], "DEA")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Référent de la prise en charge
        //         //Cocher BMO/SIMO/DBL
        //         $pdf->SetXY(51, 130);
        //         if (str_contains($formsData[$i][21], "BMO\/SIMO\/DBL")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher BEX/SBD/DBL
        //         $pdf->SetXY(50, 136);
        //         if (str_contains($formsData[$i][21], "BEX\/SBD\/DBL")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher BPTM/SBD/DBL
        //         $pdf->SetXY(51, 144);
        //         if (str_contains($formsData[$i][21], "BPTM\/SBD\/DBL")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Cocher BMT/SQUR/DEA
        //         $pdf->SetXY(51, 151);
        //         if (str_contains($formsData[$i][21], "BMT\/SQUR\/DEA")) {
        //             $pdf->Write(8, '4');
        //         }

        //         //Observations
        //         $pdf->SetXY(25, 172);
        //         $pdf->SetFont('Helvetica');
        //         $pdf->Write(8, strip_tags($formsData[$i][22]));

        //         //Signalement clôturé le
        //         $pdf->SetXY(68, 229);
        //         $pdf->Write(8, date('d/m/Y', strtotime($formsData[$i][23])));
        //     }

        // }
        // // Gérer le fichier pdf
        // $pdfContent = $pdf->Output("", 'S');
        // file_put_contents("Signalement" . $formsData[$i][1] . ".pdf", $pdfContent);

        $htmlContent = "
            <!DOCTYPE html>
            <html lang='fr'>
            <head>
                <meta charset='UTF-8'>
                <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                <title>GLPI</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        margin: 0;
                        padding: 0;
                        background-color: #f9f9f9;
                    }
                    .container {
                        max-width: 600px;
                        margin: 20px auto;
                        padding: 20px;
                        background-color: #ffffff;
                        border-radius: 10px;
                        box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
                    }
                    p {
                        font-size: 16px;
                        line-height: 1.6;
                        color: #333333;
                        margin-bottom: 10px;
                    }
                    .footer {
                        font-size: 14px;
                        color: #666666;
                        text-align: right;
                        margin-top: 20px;
                    }
                    .logo {
                        text-align: center;
                        margin-bottom: 20px;
                    }
                    .logo img {
                        max-width: 100px;
                        height: auto;
                    }
                </style>
            </head>
            <body>

                <div class='container'>
                    <div class='logo'>
                        <img src='data:image/png;base64," . base64_encode(file_get_contents($urlLogo)) . "' alt='Logo'>
                    </div>
                    <p>Bonjour,</p>
                    <p>Veuillez trouver ci-joint le document contenant plus de détails sur la réponse au formulaire de signalement de dysfonctionnement en date du ". date('d/m/Y', strtotime($formsData[$i][1])).".</p>
                    <p>N'hésitez pas à nous contacter si vous avez des questions.</p>
                    <p>Cordialement,</p>
                    <p>". $expeditor_signature ."</p>
                </div>

            </body>
            </html>
            ";

        // Pour les mail des récipiendaires: 
        $mailRecipient = "lessie.reichel@ethereal.email";
        // SendMail($htmlContent, "Signalement" . $formsData[$i][1] . ".pdf", $pdfContent, $mailRecipient, date('d/m/Y', strtotime($formsData[$i][1])), $formsData[$i][30]);
        SendMail($htmlContent, $mailRecipient, date('d/m/Y', time()));

//     }
// }
